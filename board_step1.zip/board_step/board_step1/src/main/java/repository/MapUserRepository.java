package repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapUserRepository implements UserRepository{
    private Map<String, User> map = new HashMap<>();
    @Override
    public void add(User user) {
        map.put(user.getId(), user);
    }

    @Override
    public void modify(User user) {
        map.put(user.getId(), user);
    }

    @Override
    public User remove(String id) {
        return map.remove(id);
    }

    @Override
    public User getUser(String id) {
        return map.get(id);
    }

    @Override
    public List<User> getUsers() {
        List<User> users = new ArrayList<>();
        for(User user : map.values()){
            users.add(user);
        }

        return users;
    }
}
