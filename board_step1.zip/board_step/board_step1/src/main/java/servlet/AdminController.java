package servlet;

import lombok.extern.slf4j.Slf4j;
import repository.UserRepository;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Slf4j
public class AdminController implements Command {
    @Override
    public String execute(HttpServletRequest req, HttpServletResponse resp) {
        UserRepository userRepository = (UserRepository) req.getServletContext().getAttribute("userRepository");
        req.getServletContext().setAttribute("userRepositoryList", userRepository.getUsers());
        return "/admin.jsp";
    }
}
