package servlet;

import lombok.extern.slf4j.Slf4j;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Objects;

@Slf4j
@WebServlet(name ="loginServlet", urlPatterns = "/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        resp.setCharacterEncoding("UTF-8");
        if(Objects.isNull(session)){
            resp.sendRedirect("/login.jsp");
        }
        else{
            // init 으로 변경하기.
            session.invalidate();
            resp.sendRedirect("/login.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String[] param = getServletContext().getInitParameter("admin").split(",");

        String initParamId = param[0];
        String initParamPwd = param[1];

        String id = req.getParameter("id");
        String pwd = req.getParameter("pw");

        if(initParamId.equals(id) && initParamPwd.equals(pwd)){
            HttpSession session = req.getSession();
            session.setAttribute("id", id);

            resp.sendRedirect("/admin.do");
        }
        else{
            resp.sendRedirect("/login.jsp");
        }
    }
}
