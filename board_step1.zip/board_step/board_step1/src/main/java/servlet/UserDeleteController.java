package servlet;

import repository.User;
import repository.UserRepository;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public class UserDeleteController implements Command {
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        UserRepository userRepository = (UserRepository) request.getServletContext().getAttribute("userRepository");
        userRepository.remove(request.getParameter("modifyAndDelete"));

        return "redirect:/admin/register.do";
    }
}
