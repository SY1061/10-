package servlet;

import repository.CustomUser;
import repository.User;
import repository.UserRepository;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

public class UserModifyController implements Command{
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        UserRepository userRepository = (UserRepository) request.getAttribute("UserRepository");
        String modifyId = request.getParameter("modifyAndDelete");
        User modifyUser = userRepository.getUser(modifyId);
        userRepository.modify(modifyUser);
        return "redirect:/admin/register.do";
    }
}
