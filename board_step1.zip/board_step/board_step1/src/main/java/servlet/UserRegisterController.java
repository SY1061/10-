package servlet;

import lombok.extern.slf4j.Slf4j;
import repository.CustomUser;
import repository.User;
import repository.UserRepository;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;

@Slf4j
public class UserRegisterController implements Command{
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) {
        CustomUser user = new CustomUser(
                request.getParameter("newId"),
                request.getParameter("newPw"),
                request.getParameter("newName"),
                request.getParameter("newProfile")
        );

        UserRepository userRepository = (UserRepository) request.getServletContext().getAttribute("userRepository");
        userRepository.add(user);
        request.getServletContext().setAttribute("userRepositoryList", userRepository.getUsers());
        return "/admin.jsp";
    }
}

